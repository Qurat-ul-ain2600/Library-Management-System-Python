# Library Management System

A menu-driven Python mini project built using Object-Oriented Programming (OOP).

## Features

- Add new books
- View all books
- Search books
- Issue books
- Return books
- Remove books
- View book categories
- View currently issued books
- Display library statistics
- Store data permanently using a CSV file
- Handle invalid input using exception handling

## Python Concepts Demonstrated

- Variables
- Conditional statements
- `for` and `while` loops
- Functions
- Classes and objects
- Constructors
- Methods
- Lists
- Tuples/sequence concepts
- Sets
- Dictionaries
- List comprehensions
- Exception handling
- CSV file handling
- String methods

## Project Structure

```text
Library_Management_System/
│
├── library_management.py
├── library_books.csv
└── README.md
```

`library_books.csv` is created automatically when you add the first book.

## How to Run

1. Open the project folder in VS Code.
2. Make sure Python is installed.
3. Open the VS Code terminal.
4. Run:

```bash
python library_management.py
```

## Menu

1. Add New Book
2. View All Books
3. Search Book
4. Issue Book
5. Return Book
6. Remove Book
7. View Book Categories
8. View Issued Books
9. Library Statistics
10. Exit

## Author

Python OOP Mini Project
